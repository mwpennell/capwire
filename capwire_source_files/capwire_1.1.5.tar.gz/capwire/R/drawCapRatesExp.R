drawCapRatesExp <-
function(r){
	function(n) rexp(n, rate=r)
}
