drawCapRatesBeta <-
function(shape1, shape2){
	function(n) rbeta(n, shape1, shape2)
}
