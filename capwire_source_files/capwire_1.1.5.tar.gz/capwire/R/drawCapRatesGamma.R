drawCapRatesGamma <-
function(shape, rate){
	function(n) rgamma(n, shape=shape, rate=rate)
}
