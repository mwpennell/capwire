drawCapRatesGeom <-
function(p){
	function(n) rgeom(n, prob=p)
}
