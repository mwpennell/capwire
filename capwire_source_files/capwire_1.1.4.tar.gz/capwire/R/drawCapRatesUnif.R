drawCapRatesUnif <-
function(lower, upper){
	function(n) runif(n, min=lower, max=upper)
}
